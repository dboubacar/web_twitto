

function makeMainPanel (fromId) {
	if(fromId==undefined){
		fromId=-1;
	}
	 $('head link').remove();
	 $('head').append('<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">');
	 $('head').append('<link id="fcss" rel="stylesheet" href="./css/main.css" />');
	// alert("bonjour");
		
		
		var s="";
		//en tete
		    s='<body><header><div id="tete"><div class="head"><div id="home"> <a  href="#" >Acceuil</a> <a class="twitt" href="#" >Twittor</a>\
			</div></div><div class="head"> <div id="logo"> <img src="./icon/logo.svg" /></div> </div> ';
			s+='<div class="head"> <div class="wrap"><div class="search">';
     	    s+='<input type="text" class="searchTerm" placeholder="Vous cherchez quoi?">';
     		s+='<button type="submit" class="searchButton"><i class="fa fa-search"></i></button>';
			s+='</div></div></div><div class="head">';
			s+='<div class="out"><input id="submit" type="submit" value="Deconnexion">'; 
			s+='</div></div></div></header>';
		if(fromId<0){
			s+='<div id="middle"><div class="main"><div id="profil"><div class="tof"><img src="./icon/profil.jpg"/>';
			s+='</div><div class="tof"><p><label > Diallo </label></p><p><label > sidiq</label></p></div>';
			s+='</div><div id="stats"><div class="tweets"><p class="l">Tweets</p>';
			s+='<p class="chiffre1"> 314</p></div><div class="tweets">';
			s+='<p class="l"><a href="#" onclick="makeMainPanel(2);">Abonnements</a></p>';
			s+='<p class="chiffre2"> 364</p></div><div class="tweets"><p class="l">Abonnes</p>';
		    s+='<p class="chiffre3"> 102</p></div>';
			s+='</div></div><div class="main"><div id="ntext">';
			
			s+='<form onsubmit="return newMessage(this);">';
		    s+='<textarea  id="textmsg" rows="2" cols="50"></textarea>';
		    s+='<input class="bposter" type="submit" value="Poster" />   </form>';
		    	
			s+='</div><div id="ltext"><div id="allmsg"></div></div></div>';
			s+='<div class="main"><div id="propos"><h5> A Propos </h5>';
            s+='<p> 2018 Twittor propos Centre d\'assistance Conditions Politique de confidentialité Cookies Informations sur la publicité Marque Blog État';
			s+='du service Applications Offres d\'emploi Marketing Professionnels Développeur</p>';
			s+='</div></div></div></body>';
		}
		else{
			s+='<div id="middle"><div id="profile"><p id="plog">  BOUBACAR DIALLO	</p>';
			s+='<div id="s"> <div id="ditw"><div class="ptweets"><p class="pt">Tweets</p>';
			s+='<p class="pchiffre"> 314</p></div><div class="ptweets">';
			s+='<p class="pt">Tweets</p><p class="pchiffre"> 314</p></div>';
			s+='<div class="ptweets"><p class="pt">Tweets</p><p class="pchiffre"> 314</p>';
			s+='</div></div><div id="bt"><input id="pbsuivre" type="submit" value="Suivre" />';
			s+='</div></div></div><div id="pallmsg"><p> liste message</p></div></div> <script>$("#middle").css("display","block");</script></body>';
		}
		
		$('body').html(s);
		$((completeMessages()));

		
	
}

