
function init(){
	env = new Object();
	
	
	env.follows=[];
	env.followers=[];
	env.msg=[];
	env.lastId=-1;
	env.maxId=-1;
	env.minId=-1;
	env.nbMax=-1;
	env.from=-1;
	env.noConnection=false;
	env.key="0e1dc2a9-57e4-4e4e-9d60-ae08d7edcbb5";
	env.id=1;
	env.login="sidi1";
	
	
}