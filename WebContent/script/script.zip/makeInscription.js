function makeInscription(){
    $('head link').remove();

    $('head').append('<link id="fcss" rel="stylesheet" href="../css/inscription.css" />');
 var s="";
    s+='<body> <header><div id="log"> <a href="#" >Connexion </a> </div>\
        </header><div id="middle"><div id="first"><form>  <div class="titre"><h1>Twittor</h1></div>\
          <div class="ouvrir"> <h3>Rejoignez nous</h3> </div>\
        <div class="nom"><span>Nom : </span><input id="nom" type="text"  placeholder="votre nom"/></label>\
        </div><div class="prenom"><span>Prenom : </span><input id="prenom" type="text"  placeholder="votre prenom"/></label>\
        </div><div class="idlogin"><span>Login : </span><input id="login" type="text"  placeholder="Login"/></label>\
        </div><div class="idpass"><spam>Mot de passe :</spam><input id="pass" placeholder="Mot de Passe" type="text">\
         </div><div class="valid"><input id="submit" type="submit" value="Inscription"> \
        </div></form></div></div> </body>';

        $('body').html(s);


}