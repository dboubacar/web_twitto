function newMessage(f){
	if(f.textmsg.value.length>0){
		
		//alert(f.textmsg.value);
		ajoutMessage(f.textmsg.value);
		return false;
	}
	
}

function newCom(f,idmsg){
	
	if(f.ameliorer.value.length>0 && idmsg!=undefined){
		
		//alert(f.textmsg.value);
		//lert(idmsg);
		ajoutCom(f.ameliorer.value,idmsg);
		return false;
	}
	
}