function connecte(login, pass) {
	
	if (!env.noConnection) {
		$.ajax({
			type : "GET",
			url : "http://localhost:8080/Twitto//LoginUser",
			data : "login="+login+"&password="+pass,
			datatype : "json",
			error : function(jqXHR, textStatus, errorThrown) {
				alert(textStatus);
			},
			success : function (rep) {
				responseConnexion(rep);
			}
		});
	} else {
		alert("mode Locale");
	}
}

function responseConnexion(rep) {
	var json = rep;
	mys= JSON.parse(json);
	if (mys.codError == -1) {
		$('#merror').text("Aucun user avec ce login").css("color" ,"red");
		
	} else if (mys.codError == 1) {
		$('#merror').text("Login ou mot de passe incorrects!").css("color" ,"red");
	} else {
	env.follows.push(3);
			env.follows.push(2);
		env.follows.push(4);
		//$((makeMainPanel(-1)));
		$('.chiffre2').text(env.follows.length);
		//alert("Tout okkkkk");
		 $((makeMainPanel(-1)));

	}
}
function completeMessages() {
	var max =env.maxId;
	var min =env.minId;
	var from=env.from;
	var nbMax=env.nbMax;
	//alert(env.key);
	var key=env.key;
	
	if (key != undefined) {
		if (!env.noConnection)  {
			$.ajax ({
				type:"GET",
				url:"http://localhost:8080/Twitto//getMessages",
				datatype:"text/plain",
				data:"key=" +key+ "&from=" +from+ "&idMin=" +min+ "&idMax=" +max+ "&nbMax="+nbMax,
				datatype : "json",
				error : function(jqXHR, textStatus, errorThrown) {
					alert(textStatus);
				},
				success : function (rep) {
					completeMessagesResponse(rep);
				}
			});
		}
	}
}
function refreshMessages() {
	//alert("refreshMessages()");
	//alert(env.key);
	//alert(env.from);
	//alert(env.maxId);
	if (env.key != undefined) {
		if (!env.noConnection)  {
			$.ajax ({
				type:"GET",
				url:"http://localhost:8080/Twitto//getMessages",
				datatype:"text/plain",
				data:"key="+env.key+ "&from="+env.from+"&idMin="+env.maxId+"&idMax=-1&nbMax=1",
				datatype : "json",
				error : function(jqXHR, textStatus, errorThrown) {
					alert(textStatus);
				},
				success : function (rep) {
					//alert("refreshMessagesresponse()");
					refreshMessagesresponse(rep);
				}
			});
		}
	}
}

function refreshCom() {
	//alert("refreshMessages()");
	//alert(env.key);
	//alert(env.from);
	//alert(env.maxId);
	if (env.key != undefined) {
		if (!env.noConnection)  {
			$.ajax ({
				type:"GET",
				url:"http://localhost:8080/Twitto//getMessages",
				datatype:"text/plain",
				data:"key="+env.key+ "&from="+env.from+"&idMin="+env.maxId+"&idMax=-1&nbMax=1",
				datatype : "json",
				error : function(jqXHR, textStatus, errorThrown) {
					alert(textStatus);
				},
				success : function (rep) {
					//alert("refreshMessagesresponse()");
					refreshComresponse(rep);
				}
			});
		}
	}
}


function revival(key,value) {
	console.log("in revival");
	if(value.error == 0 ){
		alert("error");
		var o = new Object(value.error);
		return o;
	}
	if(value.parent_id===-1 || value.comments!=undefined){
		//alert("Message "+value._id);
		var m=new Message(value._id,value.login,value.text,value.datem,value.comments);
		
	
		return m;
	}else if(value.parent_id !=undefined && value.parent_id !=-1){
		//alert("com "+value._id);
		var c = new Commentaire(value._id,value.login,value.text,value.datem);
		return c;
	}
	else {
		//var c = new Commentaire(12,"kante","bonjour","12/02/2014");
	
		return value;
	}
}

function completeMessagesResponse(message) {
	var tab = JSON.parse(message,revival).messages;
	
	//alert(tab[0]);
	//alert(tab);
	for (var i=tab.length-1; i>=0; i--) {
		//alert("welll");
		//alert(tab[i].id);
	    if(tab[i].comments!=undefined)
	    {   //alert(tab[i].comments);
	    	$("#allmsg").append(tab[i].getHtml());
	    }
		env.msg[tab[i].id]=tab[i];
		if (tab[i].id > env.maxId) {
			env.maxId = tab[i].id;
		}
		if ((env.minId < 0) || (tab[i].id < env.minId)) {
			env.minId = tab[i].id;
		}
		lastId = tab[i].id;
	   
	}
	env.lastId=lastId;
	
	//var t=[1,2,3]
	//alert(localdb.length);
	//alert(tab[1]);
	//alert(tab[2]);
	
}
function refreshMessagesresponse(rep){
var tab = JSON.parse(rep,revival).messages;
	
	//alert(tab[0]);
	//alert(tab);
	for (var i=tab.length-1; i>=0; i--) {
		//alert("welll");
		//alert(tab[i].id);
	    if(tab[i].comments!=undefined)
	    {   //alert(tab[i].comments);
	    	$("#allmsg").prepend(tab[i].getHtml());
	    }
		env.msg[tab[i].id]=tab[i];
		if (tab[i].id > env.maxId) {
			env.maxId = tab[i].id;
		}
		
	}
	
}

function refreshComresponse(rep){
	var tab = JSON.parse(rep,revival).messages;
		
		//alert(tab[0]);
		//alert(tab);
		for (var i=tab.length-1; i>=0; i--) {
			//alert("welll");
			//alert(tab[i].id);
		    if(tab[i].comments==undefined)
		    {   //alert(tab[i].comments);
		    	$(".modal-footer").prepend(tab[i].getHtml());
		    }
			env.msg[tab[i].id]=tab[i];
			
			
		}
		
	}

function ajoutMessage(text){
	if(!env.noConnection) {
		//alert(text);
		$.ajax ({
			type:"GET",
			url:"http://localhost:8080/Twitto//AddComment",
			datatype:"json",
			data:"key="+env.key+"&text="+text+"&parent_id=-1",
			error:function(jqXHR, textStatus, errorThrown) {
				alert(textStatus);
			},
			success: function (rep) {
				
				refreshMessages();
			}
		});
	} else {
		
	}
	
}

function ajoutCom(text,parent_id){
	if(!env.noConnection) {
		//alert(text);
		$.ajax ({
			type:"GET",
			url:"http://localhost:8080/Twitto//AddComment",
			datatype:"json",
			data:"key="+env.key+"&text="+text+"&parent_id="+parent_id,
			error:function(jqXHR, textStatus, errorThrown) {
				alert(textStatus);
			},
			success: function (rep) {
				refreshCom();
			}
		});
	} else {
		
	}
	
}


